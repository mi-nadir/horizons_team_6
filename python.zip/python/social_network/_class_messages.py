import json
from class_db_messages import DB_Messages
from __class_for_all_methods import For_Methods

from _class_account import Account

class Messages:
	def __init__(self):
		self.Account = Account()
		self.DB_Messages = DB_Messages()
		self.For_Methods = For_Methods()

	async def getdialogs(self, data):
		result = {}

		user_info = await self.Account.get_user_info(data)
		if(user_info['response']=="error"):
			return user_info
		else:
			result["response"] = "ok"
			result['data'] = ""
			return result
		#в user_info данные о юзере