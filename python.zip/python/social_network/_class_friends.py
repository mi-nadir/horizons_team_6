import json
from class_db_friends import DB_Friends
from __class_for_all_methods import For_Methods

from _class_account import Account


class Friends:
    def __init__(self):
        self.Account = Account()
        self.For_Methods = For_Methods()

    async def search(self, data):
        result = {}

        user_info = await self.Account.get_user_info(data)
        if (user_info['response'] == "error"):
            return user_info
        else:
            result["response"] = "ok"
            result['data'] = ""
            return result
            # в user_info данные о юзере
