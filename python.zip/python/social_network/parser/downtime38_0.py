import asyncio
import aiomysql
from datetime import datetime, timedelta
from models import *
from collections import deque

from datetime import datetime


async def get_status():
    statistics = []
    status = []
    id_phider = 8               # Сконнектить с сайтом
    target_date = "2024-05-17"  #

    # Подключение к базе данных
    pool = await aiomysql.create_pool(host='127.0.0.1', port=3306,
                                      user='horizons_stat', password='Stat1234',
                                      db='horizons_stat', loop=loop)

    async with pool.acquire() as connection:
        async with connection.cursor() as cursor:
            query = """
                SELECT time_, capacity 
                FROM statistic 
                WHERE id_phider = %s AND date_ = %s
                ORDER BY time_ DESC
            """
            await cursor.execute(query, (id_phider, target_date,))

            # Получение результатов запроса
            results = await cursor.fetchall()

            # Преобразование результатов в экземпляры класса Statistic
            for row in results:
                time_, capacity = row
                statistic_instance = Statistic(target_date, time_, capacity, id_phider)
                statistics.append(statistic_instance)

            await cursor.execute("""
                SELECT no_load_percent, power_raiting 
                FROM phider 
                WHERE id_phider = %s
            """, (id_phider,))
            result = await cursor.fetchone()

            if result is not None:
                no_load_percent, power_raiting = result
            else:
                no_load_percent, power_raiting = 0.2, 1000

            downtime = no_load_percent * power_raiting
            step = timedelta(minutes=1)
            temp=statistics[0]
            delta=None
            for i in range(1,len(statistics)-1):
                if statistics[i].capacity>power_raiting:
                    if temp.capacity>power_raiting:
                        delta=Status(temp.time_, statistics[i].time_, "Критический", id_phider, target_date)
                    else:
                        if delta is None:
                            delta=Status(temp.time_, statistics[i].time_, "Неопределено", id_phider, target_date)
                        status.append(delta)
                        delta=None
                        temp=statistics[i]
                elif statistics[i].capacity<downtime and len(status)>0:
                    if temp.capacity<downtime and temp.time_-statistics[i].time_>=(status[-1].time_begin-status[-1].time_end)*0.01:
                        delta=Status(temp.time_, statistics[i].time_, "Простой", id_phider, target_date)
                    else:
                        if delta is None:
                            delta=Status(temp.time_, statistics[i].time_, "Неопределено", id_phider, target_date)
                        status.append(delta)
                        delta=None
                        temp=statistics[i]
                else:
                    if temp.capacity<=power_raiting and temp.capacity>=downtime:
                        delta=Status(temp.time_, statistics[i].time_, " ", id_phider, target_date)
                    else:
                        if delta is  None:
                            delta=Status(temp.time_, statistics[i].time_, "Неопределено", id_phider, target_date)
                        status.append(delta)
                        delta=None
                        temp=statistics[i]
            insert_query = """
                INSERT INTO status (id_phider, date_status, time_begin, time_end, type_status, notification) 
                VALUES (%s, %s, %s, %s, %s, %s)
            """	
            async with connection.cursor() as insert_cursor:
                
                for s in status:
                    await insert_cursor.execute(insert_query, (s.id_phider, s.date_status, s.time_end,s.time_begin, s.type_status, 1 if s.type_status == "Критический" else 0))
                    
                await connection.commit()

    # Закрытие пула подключений
    pool.close()
    await pool.wait_closed()

    return statistics

# Создание цикла событий и запуск функции get_status()
loop = asyncio.get_event_loop()
statistics = loop.run_until_complete(get_status())
