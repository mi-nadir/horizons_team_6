import asyncio
import aiomysql

async def get_phiders_limits(loop):
    pool = await aiomysql.create_pool(host='127.0.0.1', port=3306,
                                      user='horizons_stat', password='Stat1234',
                                      db='horizons_stat', loop=loop)
    phiders_limits = {}
    async with pool.acquire() as connection:
        async with connection.cursor() as cursor:
            query = """
                SELECT id_phider, limit_max 
                FROM phider
            """
            await cursor.execute(query)
            results = await cursor.fetchall()
            for row in results:
                phiders_limits[row[0]] = row[1] if row[1] is not None else 0

    pool.close()
    await pool.wait_closed()
    return phiders_limits


import random
from datetime import datetime

async def generate_and_save_power(phiders_limits, loop):
    
    while True:
        for id_phider, max_capacity in phiders_limits.items():
            pool = await aiomysql.create_pool(host='127.0.0.1', port=3306,
                                      user='horizons_stat', password='Stat1234',
                                      db='horizons_stat', loop=loop)
            async with pool.acquire() as connection:
                async with connection.cursor() as cursor:
                    
                        # Генерация значения мощности
                        generated_capacity = random.uniform(0, max_capacity)
                            
                        # Получение текущей даты и времени
                        current_datetime = datetime.now()
                        current_date = current_datetime.date()
                        current_time = current_datetime.time()
                            
                        # Сохранение значения мощности в БД
                        query = """
                                INSERT INTO statistic (id_phider, date_, time_, capacity)
                                VALUES (%s, %s, %s, %s)
                            """
                        await cursor.execute(query, (id_phider, current_date, current_time, generated_capacity))
                        await connection.commit()

                        # Ожидание одну минуту
            pool.close()
            await pool.wait_closed()
        await asyncio.sleep(60)


