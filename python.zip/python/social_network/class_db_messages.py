import asyncio
import aiomysql

class DB_Messages:
	def __init__(self):
		self.db_host = "localhost"
		self.db_name = "admin_soc_messages"
		self.db_user = "admin_soc_msg"
		self.db_pass = "131215Aa!"
		self.db_port = 3306

	#функция для получения последних сообщений
	async def get_chat(self, uid1, uid2, limit=50):
		loop = asyncio.get_event_loop()
		conn = await aiomysql.connect(db=self.db_name,
							 user=self.db_user,
							 password=self.db_pass,
							 host=self.db_host,
							 loop=loop,
							 port=self.db_port)
		await conn.autocommit(True)
		cur = await conn.cursor(aiomysql.DictCursor)

		#проверка кол-ва запрашиваемых сообщений
		if(limit>200):
			limit = 200
		if(limit<1):
			limit = 1
		#после проверки лимита переводим его в формат string для вставки в запрос
		limit = str(limit)

		#так как имена таблиц формируются так что первым идет меньший id, а далее больший id юзера,
		#то надо проверять входящие данные и если что менять местами
		if(uid1 > uid2):
			user_id1 = str(uid2)
			user_id2 = str(uid1)
		else:
			user_id1 = str(uid1)
			user_id2 = str(uid2)

		query = "SELECT * FROM chat"+user_id1+"_"+user_id2+" ORDER BY msg_id DESC LIMIT "+limit
		await cur.execute(query)
		result = await cur.fetchall()
		await cur.close()
		conn.close()
		return result