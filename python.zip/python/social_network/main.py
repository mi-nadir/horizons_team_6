# Параметры Redis в конфиге:
# maxmemory 100mb
# maxmemory-policy volatile-ttl
# инфа об использовании redis: https://habr.com/ru/companies/vk/articles/557232/

import os
this_dir = "/python/social_network"
os.chdir(this_dir)

import asyncio
from fastapi import Request, FastAPI, Form
from _class_account import Account
from _class_friends import Friends
from _class_messages import Messages
from _class_stat import Stat

app = FastAPI()
Account = Account()
Friends = Friends()
Messages = Messages()
Stat = Stat()

#####################################################################
# Account Methods
#####################################################################

@app.post("/api/account.auth")
async def auth(request: Request):
	return await Account.auth(await request.body())

@app.post("/api/account.register")
async def register(request: Request):
	return await Account.register(await request.body())

@app.post("/api/account.confirm")
async def confirm(request: Request):
	return await Account.confirm(await request.body())

######################################################################
# Friends Methods
######################################################################

@app.post("/api/friends.search")
async def friends_search(request: Request):
	return await Friends.search(await request.body())

######################################################################
# Messages Methods
######################################################################

@app.post("/api/messages.getdialogs")
async def getdialogs(request: Request):
	return await Messages.getdialogs(await request.body())

######################################################################
# Stat
######################################################################
@app.post("/api/stat.get")
async def stat_get(request: Request):
	return await Stat.get(await request.body())