import json
from class_db_stat import DB_Stat
from class_db_users import DB_Users
from __class_for_all_methods import For_Methods
import datetime


class Stat:
    def __init__(self):
        self.DB_Stat = DB_Stat()
        self.DB_Users = DB_Users()
        self.For_Methods = For_Methods()

    async def get(self, data):
        json = self.For_Methods.parseJson(data)
        if (json["response"] == "error"):  # если неудачно
            return json

        json = json["data"]
        if ('data' in json):
            if ('token' in json['data']):
                account = await self.DB_Users.check_token(json['data']['token'])
                if(account["response"]!="ok"):
                    return "Доступ запрещен!"
                account_fio = account["data"]["lastname"]+" "+account["data"]["firstname"]
            else:
                return "Доступ запрещен!"
        else:
            return "Доступ запрещен!"

        html = ''
        with open("_page_stat.txt") as file:
            html += file.read()
        ###########################################
        html = html.replace("{$USER_FIO}", account_fio);
        ###########################################
        html = html.replace("{$THIS_TIME}", datetime.datetime.now().strftime('%d.%m.%Y %H:%m'));
        ###########################################
        result = await self.DB_Stat.get_glavn_graph()
        datas = ""
        col = 0
        itog_kvt = 0
        for info in result:
            if(col!=0):
                datas += ","
            col = col + 1
            kvt = int(int(info['total_capacity'])/60)
            itog_kvt += kvt
            datas += "["+str(col)+","+str(int(info['total_capacity']))+","+str(int(itog_kvt))+"]"

        html = html.replace("{$GLAVN_TABLE}", datas)
        ############################################
        result = await self.DB_Stat.all_phiders()
        all_code_oborud = ""
        for phider_id in result:
            no_load = str(int(phider_id['power_raiting']*phider_id['no_load_percent']))
            phider_id = str(phider_id['id_phider'])
            result2 = await self.DB_Stat.phider_info(phider_id)
            prostoy_phider = await self.DB_Stat.prostoy_phider(phider_id)
            if (prostoy_phider[0]['sum'] == None):
                prostoy_phider = str(0)
            else:
                prostoy_phider = str(round(prostoy_phider[0]['sum'] / 60, 2))

            raboty_phider = await self.DB_Stat.raboty_phider(phider_id)
            if (raboty_phider[0]['sum'] == None):
                raboty_phider = str(0)
            else:
                raboty_phider = str(round(raboty_phider[0]['sum'] / 60, 2))

            col_kryt_phider = await self.DB_Stat.col_kryt_phider(phider_id)
            if (col_kryt_phider[0]['sum'] == None):
                col_kryt_phider = str(0)
            else:
                col_kryt_phider = str(col_kryt_phider[0]['sum'])

            datas = ""
            col = 0
            itog_kvt = 0
            for info in result2:
                if (col != 0):
                    datas += ","
                col = col + 1
                kvt = int(int(info['total_capacity']) / 60)
                itog_kvt += kvt
                datas += "[" + str(col) + "," + str(int(info['total_capacity'])) + "," + str(int(itog_kvt)) + ", "+no_load+"]"

            this_code = "<div class=\"stat_block\"><div class=\"openOborud\" onclick=\"openOborud("+phider_id+");\"><h4 style=\"display: block;\">Оборудование "+phider_id+"</h4></div><div style=\"display:block;\" class=\"openOborudLoop\" id=\"oborud_"+phider_id+"\"><div class=\"onOborud_left\"><script>    google.charts.load('current', {packages: ['corechart', 'line']});google.charts.setOnLoadCallback(drawCurveTypes);function drawCurveTypes() {      var data = new google.visualization.DataTable();      data.addColumn('number', 'X');      data.addColumn('number', 'кВт');      data.addColumn('number', 'кВт/ч');    data.addColumn('number', 'Простой');      data.addRows([        "+datas+"      ]);      var options = {        hAxis: {          title: 'Время'        },        vAxis: {          title: 'кВт, кВт/ч'        },        series: {          1: {curveType: 'function'}        }      };      var chart = new google.visualization.LineChart(document.getElementById('chart_div"+phider_id+"'));      chart.draw(data, options);    }</script><div id=\"chart_div"+phider_id+"\" style=\"width: 100%; height:200px;\"></div></div><div class=\"onOborud_right\">Время работы: "+raboty_phider+" часов<br>Время простоя: "+prostoy_phider+" часов<br>Критических событий: "+col_kryt_phider+"<br>Неопределенное время: 2 часа<br><br><button style=\"cursor: pointer;\" onclick=\"open_close_oborud_card("+phider_id+");\">Открыть карточку</button></div><div style=\"clear:both;\"></div></div></div>"
            all_code_oborud += this_code
        html = html.replace("{ALL_CODE_OBORUD}", all_code_oborud);

        ############################################
        result = await self.DB_Stat.all_phiders()
        all_code_oborud = ""
        for phider in result:
            no_load = str(int(phider['power_raiting'] * phider['no_load_percent']))
            phider_id = str(phider['id_phider'])
            result2 = await self.DB_Stat.phider_info(phider_id)
            prostoy_phider = await self.DB_Stat.prostoy_phider(phider_id)
            if(prostoy_phider[0]['sum']==None):
                prostoy_phider = str(0)
            else:
                prostoy_phider = str(round(prostoy_phider[0]['sum']/60, 2))

            raboty_phider = await self.DB_Stat.raboty_phider(phider_id)
            if (raboty_phider[0]['sum'] == None):
                raboty_phider = str(0)
            else:
                raboty_phider = str(round(raboty_phider[0]['sum'] / 60, 2))

            col_kryt_phider = await self.DB_Stat.col_kryt_phider(phider_id)
            if (col_kryt_phider[0]['sum'] == None):
                col_kryt_phider = str(0)
            else:
                col_kryt_phider = str(col_kryt_phider[0]['sum'])

            datas = ""
            col = 0
            itog_kvt = 0
            for info in result2:
                if (col != 0):
                    datas += ","
                col = col + 1
                kvt = int(int(info['total_capacity']) / 60)
                itog_kvt += kvt
                datas += "[" + str(col) + "," + str(int(info['total_capacity'])) + "," + str(int(itog_kvt)) + ", "+no_load+"]"
            this_code = "<div style=\"display: block; position: relative;\" class=\"oborudCard obCardForLoop\" id=\"oborudCard_"+phider_id+"\"><div class=\"stat_block\"><div class=\"oborudCard_top_left\"><h3 style=\"display: block;\">Оборудование "+phider_id+" - "+datetime.datetime.now().strftime('%d.%m.%Y')+"</h3></div><div class=\"oborudCard_top_right\"><div onclick=\"open_close_oborud_card("+phider_id+");\" class=\"def_border oborudCard_close_btn\">Закрыть</div></div><div style=\"clear:both;\"></div><div class=\"oborudCard_left_block\"><script>    google.charts.load('current', {packages: ['corechart', 'line']});google.charts.setOnLoadCallback(drawCurveTypes);function drawCurveTypes() {      var data = new google.visualization.DataTable();      data.addColumn('number', 'X');      data.addColumn('number', 'кВт');      data.addColumn('number', 'кВт/ч');   data.addColumn('number', 'Простой');      data.addRows([        "+datas+"      ]);      var options = {        hAxis: {          title: 'Время'        },        vAxis: {          title: 'кВт, кВт/ч'        },        series: {          1: {curveType: 'function'}        }      };      var chart = new google.visualization.LineChart(document.getElementById('charts_div_card_"+phider_id+"'));      chart.draw(data, options);    }</script><div id=\"charts_div_card_"+phider_id+"\" style=\"width: 100%; height:400px;\"></div><h4>Комментарии</h4><textarea class=\"def_border oborudCard_comment\"></textarea></div><div class=\"oborudCard_right_block\"><h3 style=\"display: block; margin-right: 35px;\">Информация</h3>Номинальная мощность: "+str(phider['power_raiting'])+" кВт<br>Холостой ход: "+str(phider['no_load_percent']*100)+"%<br>Подготовительное (заключительное) время: 20%<br>Время работы: "+raboty_phider+" часов<br>Время простоя: "+prostoy_phider+" часов<br>Критических событий: "+col_kryt_phider+"<br>Неопределенное время: 2 часа<br><h3 style=\"display: block; margin-right: 35px;\">История события</h3><table><tr><th>Время</th><th>Тип события</th></tr><tr><td>9:44 - 9:54</td><td>Цех 1: Оборудование <br>Цех 2: Оборудование 2</td></tr><tr><td>9:44 - 9:54</td><td>Цех 1: Оборудование 1<br>Цех 2: Оборудование 2</td></tr></table></div><div style=\"clear:both;\"></div></div></div>"
            all_code_oborud += this_code

        html = html.replace("{ALL_CARD_OBORUD}", all_code_oborud);

        ###############################################

        result = await self.DB_Stat.kvt_day()
        kvt_day = str(int(result[0]['total_capacity'])/2)
        html = html.replace("{$KVT_DAY}", kvt_day);

        ################################################

        result = await self.DB_Stat.krit_sobyt()
        all_code_sobyt = ""
        for sobyt in result:
            if(sobyt['notification']==1):
                notif="Да"
            else:
                nofif="Нет"
            all_code_sobyt += "<tr><td>"+str(sobyt['time_begin'])+" - "+str(sobyt['time_end'])+"</td><td>Цех "+str(sobyt['id_workshop'])+": Оборудование "+str(sobyt['id_phider'])+"</td><td>"+notif+"</td></tr>"
        html = html.replace("{$CODE_SOBYT}", all_code_sobyt);

        ###########################################

        result = await self.DB_Stat.prostoy_predpr()
        html = html.replace("{PROSTOY_PREDPR}", str(round(result[0]["total_simple_status_time_hours"],2)));

        html = html.replace("{RABOTY_PREDPR}", str(24-round(result[0]["total_simple_status_time_hours"],2)));
        
        
        return html
        pass
        """result = {}
        # парсинг принятого json
        json = self.For_Methods.parseJson(data)
        if (json["response"] == "error"):  # если неудачно
            return json

        json = json["data"]

        # проверка существования данных (то что они переданы)
        if (('sign-in-login' not in json) or ('sign-in-password' not in json)):
            result["response"] = "error"
            result['error_code'] = 23
            result['error_msg'] = "Ошибка! Код 23"
            return result

        if (self.For_Methods.isEmailValid(json['sign-in-login']) == False or json[
            'sign-in-login'].islower() == False):  # в нижнем регистре и правильный Email
            result["response"] = "error"
            result['error_code'] = 24
            result['error_msg'] = "Ошибка при обработке Email"
            return result

        if (self.For_Methods.isHashSHA256Valid(json['sign-in-password']) == False):  # проверка на sha256
            result["response"] = "error"
            result['error_code'] = 25
            result['error_msg'] = "Ошибка при обработке пароля"
            return result

        result = await self.DB_Users.auth(json['sign-in-login'], json['sign-in-password'])
        return result

    async def register(self, data):
        '''redis = aioredis.from_url(
        "redis://localhost", encoding="utf-8", decode_responses=True
        )'''

        result = {}
        # парсинг принятого json
        json = self.For_Methods.parseJson(data)
        if (json["response"] == "error"):  # если неудачно
            return json

        json = json["data"]
        # проверка существования данных (то что они переданы)
        if (('sign-up-firstname' not in json) or ('sign-up-lastname' not in json) or ('sign-up-login' not in json) or (
                'sign-up-password' not in json) or ('sign-up-ok-password' not in json)):
            result["response"] = "error"
            result['error_code'] = 6
            result['error_msg'] = "Ошибка! Код 6"
            return result

        # проверка полей на валидность
        valid_error = ''
        if (len(json['sign-up-firstname']) < 3 or len(json['sign-up-firstname']) >= 20):  # >=3 букв в имени
            valid_error += 'Ошибка в поле "Имя"'
        if ((len(json['sign-up-lastname']) < 3 and len(json['sign-up-lastname']) != 0) or len(
                json['sign-up-lastname']) >= 20):  # либо >=3 букв либо 0 в фамилии
            if (valid_error != ''):
                valid_error += '<br>'
            valid_error += 'Ошибка в поле "Фамилия"'
        if (self.For_Methods.isEmailValid(json['sign-up-login']) == False or json[
            'sign-up-login'].islower() == False):  # в нижнем регистре и правильный Email
            if (valid_error != ''):
                valid_error += '<br>'
            valid_error += 'Ошибка в поле "Почта" (вводить в нижнем регистре)'
        if (json['sign-up-password'] != json['sign-up-ok-password']):  # в нижнем регистре и правильный Email
            if (valid_error != ''):
                valid_error += '<br>'
            valid_error += 'Пароли не совпадают'
        if (self.For_Methods.isHashSHA256Valid(json['sign-up-password']) == False):  # проверка на sha256
            if (valid_error != ''):
                valid_error += '<br>'
            valid_error += 'Ошибка в пароле'
        if (self.For_Methods.isValidDateFormat(json['sign-up-birthday']) == False):
            if (valid_error != ''):
                valid_error += '<br>'
            valid_error += 'Ошибка в поле "День рождения"'
        else:
            if (self.For_Methods.AgeFromDate(json['sign-up-birthday']) < 14 or self.For_Methods.AgeFromDate(
                    json['sign-up-birthday']) > 100):
                if (valid_error != ''):
                    valid_error += '<br>'
                valid_error += 'Ошибка в поле "День рождения", возраст меньше 14 или больше 100 лет'
        if (json['sign-up-sex'].isdigit() != True):
            if (valid_error != ''):
                valid_error += '<br>'
            valid_error += 'Ошибка в поле "Пол"'
        else:
            if (int(json['sign-up-sex']) < 0 or int(json['sign-up-sex']) > 2):
                if (valid_error != ''):
                    valid_error += '<br>'
                valid_error += 'Ошибка в поле "Пол"'

        if (valid_error != ''):
            result["response"] = "error"
            result['error_code'] = 7
            result['error_msg'] = valid_error
            return result

        # генерация 6 значного кода подтверждения
        register_code = self.For_Methods.generateVerifyCode()
        # Текст регистрации
        register_text = "Спасибо за регистрацию в Faqel\n\nВаш код подтверждения: " + register_code + "\n\nЕсли это письмо пришло вам по ошибке - просто проигнорируйте его"
        # Генерируем соль для пароля
        pass_salt = self.For_Methods.generate_password(32)
        # Шифруем шифрованный пароль еще раз с помощью соли
        password_sha256 = self.For_Methods.sha256(json['sign-up-password'] + pass_salt)
        # Записываем в БД
        add_to_db_result = await self.DB_Users.add_reg_queue(json['sign-up-firstname'], json['sign-up-lastname'],
                                                             json['sign-up-birthday'], json['sign-up-sex'],
                                                             json['sign-up-login'], password_sha256, pass_salt,
                                                             register_code)
        # print(add_to_db_result)
        self.For_Methods.SendMail(json['sign-up-login'], "Подтверждение регистрации в Faqel", register_text)

        return add_to_db_result

    async def confirm(self, data):
        result = {}
        # парсинг принятого json
        json = self.For_Methods.parseJson(data)
        if (json["response"] == "error"):  # если неудачно
            return json

        json = json["data"]
        # проверка существования данных (то что они переданы)
        if (('confirm_id' not in json) or ('confirm_code' not in json)):
            result["response"] = "error"
            result['error_code'] = 12
            result['error_msg'] = "Ошибка! Код 12"
            return result

        if (len(json['confirm_code']) != 8 or json['confirm_code'].isdigit() != True):
            result["response"] = "error"
            result['error_code'] = 13
            result['error_msg'] = "Ошибка! Код 13"
            return result

        confirm_id = json['confirm_id'].split(" ", 1)  # делим строку по пробелу на максимум 2 части
        if (self.For_Methods.isEmailValid(confirm_id[1]) == False or confirm_id[1].islower() == False or confirm_id[
            0].isdigit() == False):  # в нижнем регистре, правильный Email и код числовой
            result["response"] = "error"
            result['error_code'] = 14
            result['error_msg'] = "Ошибка! Код 14"
            return result

        check_result = await self.DB_Users.check_reg_code(confirm_id[0], confirm_id[1], json['confirm_code'])

        return check_result

    ###########################################################
    ## Не для API методов, а для получения данных о юзерах
    ###########################################################
    async def get_user_info(self, data):
        result = {}
        # парсинг принятого json
        json = self.For_Methods.parseJson(data)
        if (json["response"] == "error"):  # если неудачно
            return json

        json = json["data"]
        if ('data' in json):
            if ('token' in json['data']):
                result = await self.DB_Users.check_token(json['data']['token'])
                if (result['response'] == "ok"):
                    return result
                else:
                    result["response"] = "error"
                    result['error_code'] = 37
                    result['error_msg'] = "Ошибка! Код 37"
                    return result
            else:
                result["response"] = "error"
                result['error_code'] = 31
                result['error_msg'] = "Ошибка! Код 31"
                return result
        else:
            result["response"] = "error"
            result['error_code'] = 31
            result['error_msg'] = "Ошибка! Код 31"
            return result
        """