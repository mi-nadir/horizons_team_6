import json
import re
import datetime
import smtplib
from email.message import EmailMessage
import random
import string
import asyncio
import aiomysql
import time
import hashlib

class For_Methods:
	def __init__(self):
		pass

	async def db_connect(self, db_name, db_user, db_pass, db_host, db_port):
		try:
			loop = asyncio.get_event_loop()
			conn = await aiomysql.connect(db=db_name,
								 user=db_user,
								 password=db_pass,
								 host=db_host,
								 loop=loop,
								 port=db_port)
			await conn.autocommit(True)
			result = {}
			result['loop'] = loop
			result['connect'] = conn
			return result
		except:
			return False

	async def db_disconnect(self, connect):
		try:
			connect.close()
		except:
			return False

	async def db_select_one(self, loop, sql, data, connect):
		try:
			cur = await connect.cursor(aiomysql.DictCursor)
			await cur.execute(sql, data)
			r = await cur.fetchone()
			await cur.close()
			return r
		except:
			return False

	async def db_insert(self, loop, sql, data, connect):
		try:
			cur = await connect.cursor(aiomysql.DictCursor)
			await cur.execute(sql, data)
			await connect.commit()
			insert_row_id = cur.lastrowid #получаем id вставленной строки
			await cur.close()
			return insert_row_id # возвращаем id вставленной строки
		except:
			return False

	async def db_delete(self, loop, sql, data, connect):
		try:
			cur = await connect.cursor(aiomysql.DictCursor)
			await cur.execute(sql, data)
			await connect.commit()
			await cur.close()
		except:
			return False

	async def db_update(self, loop, sql, data, connect):
		try:
			cur = await connect.cursor(aiomysql.DictCursor)
			await cur.execute(sql, data)
			await connect.commit()
			await cur.close()
		except:
			return False

	def genetate_error_code(self, code, text=False):
		result = {}
		result["response"] = "error"
		result['error_code'] = code
		if(text == False):
			result['error_msg'] = "Ошибка! Код "+str(code)
		else:
			result['error_msg'] = text
		return result

	def generate_token(self):
		return self.sha256(self.generate_password(32))

	# удаляет из массива токены с истекшим сроком (более 30 дней)
	def delete_expired_tokens(self, tokens): #принимает не json, а массив
		checked_tokens = []

		aa = datetime.date.fromisoformat(self.date_today())
		for token in tokens:
			bb = datetime.date.fromisoformat(token["last_use_date"])
			datetime.delta = abs(aa - bb)
			if(int(datetime.delta.days)<=30):
				checked_tokens.append(token)

		return checked_tokens

	# работа с токенами (получает json или пустую строку, отдает json)
	def add_token_to_json(self, tokens, add_token):
		try: # попытка парсинга json
			tokens = json.loads(tokens)

			if(len(tokens)>=10): # если 10 и более токенов
				tokens.pop() # то удаляем последний элемент, чтобы в начало записать новый токен

			token = {}
			token["token"] = add_token
			token["last_use_date"] = self.date_today()

			tokens.insert(0, token) # вставляем в начало сгенеренный токен
		except: #если парсинг не удался, то считаем массив пустым
			tokens = []

			token = {}
			token["token"] = add_token
			token["last_use_date"] = self.date_today()
			tokens.append(token)

		tokens = self.delete_expired_tokens(tokens)

		return json.dumps(tokens)

	def check_token_on_json(self, tokens, check_token): #принимает не json, а массив
		try: # попытка парсинга json
			tokens = json.loads(tokens)
		except:
			return False

		aa = datetime.date.fromisoformat(self.date_today())
		for token in tokens:
			bb = datetime.date.fromisoformat(token["last_use_date"])
			datetime.delta = abs(aa - bb)
			if(int(datetime.delta.days)<=30 and check_token==token["token"]):
				return True

		return False



	# парсинг JSON
	def parseJson(self, data):
		result = {}
		try:
			result = self.stripDict(json.loads(data))
		except:
			result = self.genetate_error_code(4)
		return result

	# для защиты от XSS
	def htmlspecialchars(self, text):
		return (
			text.replace("&", "&amp;").
			replace('"', "&quot;").
			replace("<", "&lt;").
			replace(">", "&gt;")
		)

	# удаление пробелов в начале и конце строки
	def stripDict(self, dictionary):
		result = {}
		try:
			for key in dictionary:
				if isinstance(dictionary[key], dict): # проверка на словарь (типа двумерный массив или нет)
					for key2 in dictionary[key]:
						dictionary[key][key2] = self.htmlspecialchars(dictionary[key][key2].strip())
				else: # если нет
					dictionary[key] = self.htmlspecialchars(dictionary[key].strip())

			result['response'] = "ok"
			result['data'] = dictionary
		except:
			result = self.genetate_error_code(5)
		return result

	# проверка валидности SHA 256 хеша
	def isHashSHA256Valid(self, hash):
		regex = r'^[a-f0-9]{64}$'
		if(re.fullmatch(regex, hash)):
			return True
		else:
			return False

	# проверка валидности email
	def isEmailValid(self, email):
		regex = r'^(([^<>()[\].,;:\s@"]+(\.[^<>()[\].,;:\s@"]+)*)|(".+"))@(([^<>()[\].,;:\s@"]+\.)+[^<>()[\].,;:\s@"]{2,})$'
		if(re.fullmatch(regex, email)):
			return True
		else:
			return False

	def isValidDateFormat(self, date_text):
		try:
			datetime.date.fromisoformat(date_text)
			return True
		except ValueError:
			return False

	def AgeFromDate(self, date_text):
		a = datetime.date.fromisoformat(date_text)
		b = datetime.date.today()
		return int((b-a).days / (365.2425))

	def current_unixtime(self):
		return int(time.time())

	def date_today(self):
		return datetime.date.today().strftime('%Y-%m-%d')

	def SendMail(self, to, subject, text):
		email_address = 'noreply@faqel.com'
		email_password = 'oM=(zl22-(E9=wQP'

		# create email
		msg = EmailMessage()
		msg['Subject'] = subject
		msg['From'] = email_address
		msg['To'] = to
		msg.set_content(text)

		# send email
		with smtplib.SMTP_SSL('localhost', 465) as smtp:
			smtp.login(email_address, email_password)
			smtp.send_message(msg)

	# генератор 8 значных кодов подтверждения
	def generateVerifyCode(self):
		rand_num = str(random.randint(0,99999999))
		for x in range(8-len(rand_num)):
			rand_num = "0"+rand_num
		return rand_num

	# генератор случайных паролей / соли указанной длины
	def generate_password(self, length):
		characters = string.ascii_letters + string.digits + string.punctuation
		password = ''.join(random.choice(characters) for _ in range(length))
		return password

	def sha256(self, text):
		return hashlib.sha256(text.encode('utf-8')).hexdigest()