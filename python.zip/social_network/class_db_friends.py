import asyncio
import aiomysql

class DB_Friends:
    def __init__(self):
        self.db_host = "localhost"
        self.db_name = "vipok72_soc_friends"
        self.db_user = "vipok72_soc_frn"
        self.db_pass = "KO?P^tz5oFI:@@N:"
        self.db_port = 3306

    #функция для получения последних сообщений
    async def create_table_friends(self, uid):
        db = await self.For_Methods.db_connect(self.db_name, self.db_user, self.db_pass, self.db_host, self.db_port)

        sql = "CREATE TABLE `"+str(uid)+"`(`id` int NOT NULL, `user_id` bigint NOT NULL, `firstname` varchar(20) NOT NULL, `lastname` varchar(20) NOT NULL, `password_to_hide` varchar(64) NOT NULL)"
        sql = "ALTER TABLE `"+str(uid)+"` ADD PRIMARY KEY(`id`);"
        sql = "ALTER TABLE `"+str(uid)+"` MODIFY `id` int NOT NULL AUTO_INCREMENT;"

