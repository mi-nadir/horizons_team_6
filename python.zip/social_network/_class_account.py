import json
from class_db_users import DB_Users
from __class_for_all_methods import For_Methods

class Account:
	def __init__(self):
		self.DB_Users = DB_Users()
		self.For_Methods = For_Methods()

	async def auth(self, data):
		result = {}
		# парсинг принятого json
		json = self.For_Methods.parseJson(data)
		if(json["response"]=="error"): # если неудачно
			return json
		
		json = json["data"]

		#проверка существования данных (то что они переданы)
		if(('sign-in-login' not in json) or ('sign-in-password' not in json)):
			result["response"] = "error"
			result['error_code'] = 23
			result['error_msg'] = "Ошибка! Код 23"
			return result

		if(self.For_Methods.isEmailValid(json['sign-in-login'])==False or json['sign-in-login'].islower()==False): # в нижнем регистре и правильный Email
			result["response"] = "error"
			result['error_code'] = 24
			result['error_msg'] = "Ошибка при обработке Email"
			return result

		if(self.For_Methods.isHashSHA256Valid(json['sign-in-password'])==False): # проверка на sha256
			result["response"] = "error"
			result['error_code'] = 25
			result['error_msg'] = "Ошибка при обработке пароля"
			return result

		result = await self.DB_Users.auth(json['sign-in-login'], json['sign-in-password'])
		return result


	async def register(self, data):
		'''redis = aioredis.from_url(
		"redis://localhost", encoding="utf-8", decode_responses=True
		)'''

		result = {}
		# парсинг принятого json
		json = self.For_Methods.parseJson(data)
		if(json["response"]=="error"): # если неудачно
			return json
		
		json = json["data"]
		#проверка существования данных (то что они переданы)
		if(('sign-up-firstname' not in json) or ('sign-up-lastname' not in json) or ('sign-up-login' not in json) or ('sign-up-password' not in json) or ('sign-up-ok-password' not in json)):
			result["response"] = "error"
			result['error_code'] = 6
			result['error_msg'] = "Ошибка! Код 6"
			return result

		# проверка полей на валидность
		valid_error = ''
		if(len(json['sign-up-firstname'])<3 or len(json['sign-up-firstname'])>=20): # >=3 букв в имени
			valid_error += 'Ошибка в поле "Имя"'
		if((len(json['sign-up-lastname'])<3 and len(json['sign-up-lastname'])!=0) or len(json['sign-up-lastname'])>=20): # либо >=3 букв либо 0 в фамилии
			if(valid_error != ''):
				valid_error += '<br>'
			valid_error += 'Ошибка в поле "Фамилия"'
		if(self.For_Methods.isEmailValid(json['sign-up-login'])==False or json['sign-up-login'].islower()==False): # в нижнем регистре и правильный Email
			if(valid_error != ''):
				valid_error += '<br>'
			valid_error += 'Ошибка в поле "Почта" (вводить в нижнем регистре)'
		if(json['sign-up-password']!=json['sign-up-ok-password']): # в нижнем регистре и правильный Email
			if(valid_error != ''):
				valid_error += '<br>'
			valid_error += 'Пароли не совпадают'
		if(self.For_Methods.isHashSHA256Valid(json['sign-up-password'])==False): # проверка на sha256
			if(valid_error != ''):
				valid_error += '<br>'
			valid_error += 'Ошибка в пароле'
		if(self.For_Methods.isValidDateFormat(json['sign-up-birthday'])==False):
			if(valid_error != ''):
				valid_error += '<br>'
			valid_error += 'Ошибка в поле "День рождения"'
		else:
			if(self.For_Methods.AgeFromDate(json['sign-up-birthday'])<14 or self.For_Methods.AgeFromDate(json['sign-up-birthday'])>100):
				if(valid_error != ''):
					valid_error += '<br>'
				valid_error += 'Ошибка в поле "День рождения", возраст меньше 14 или больше 100 лет'
		if(json['sign-up-sex'].isdigit()!=True):
			if(valid_error != ''):
				valid_error += '<br>'
			valid_error += 'Ошибка в поле "Пол"'
		else:
			if(int(json['sign-up-sex'])<0 or int(json['sign-up-sex'])>2):
				if(valid_error != ''):
					valid_error += '<br>'
				valid_error += 'Ошибка в поле "Пол"'

		if(valid_error!=''):
			result["response"] = "error"
			result['error_code'] = 7
			result['error_msg'] = valid_error
			return result

		# генерация 6 значного кода подтверждения
		register_code = self.For_Methods.generateVerifyCode()
		# Текст регистрации
		register_text = "Спасибо за регистрацию в Faqel\n\nВаш код подтверждения: "+register_code+"\n\nЕсли это письмо пришло вам по ошибке - просто проигнорируйте его"
		# Генерируем соль для пароля
		pass_salt = self.For_Methods.generate_password(32)
		# Шифруем шифрованный пароль еще раз с помощью соли
		password_sha256 = self.For_Methods.sha256(json['sign-up-password']+pass_salt)
		# Записываем в БД
		add_to_db_result = await self.DB_Users.add_reg_queue(json['sign-up-firstname'], json['sign-up-lastname'], json['sign-up-birthday'], json['sign-up-sex'], json['sign-up-login'], password_sha256, pass_salt, register_code)
		#print(add_to_db_result)
		self.For_Methods.SendMail(json['sign-up-login'], "Подтверждение регистрации в Faqel", register_text)

		return add_to_db_result

	async def confirm(self, data):
		result = {}
		# парсинг принятого json
		json = self.For_Methods.parseJson(data)
		if(json["response"]=="error"): # если неудачно
			return json
		
		json = json["data"]
		#проверка существования данных (то что они переданы)
		if(('confirm_id' not in json) or ('confirm_code' not in json)):
			result["response"] = "error"
			result['error_code'] = 12
			result['error_msg'] = "Ошибка! Код 12"
			return result

		if(len(json['confirm_code'])!=8 or json['confirm_code'].isdigit()!=True):
			result["response"] = "error"
			result['error_code'] = 13
			result['error_msg'] = "Ошибка! Код 13"
			return result

		confirm_id = json['confirm_id'].split(" ", 1) # делим строку по пробелу на максимум 2 части
		if(self.For_Methods.isEmailValid(confirm_id[1])==False or confirm_id[1].islower()==False or confirm_id[0].isdigit()==False): # в нижнем регистре, правильный Email и код числовой
			result["response"] = "error"
			result['error_code'] = 14
			result['error_msg'] = "Ошибка! Код 14"
			return result

		check_result = await self.DB_Users.check_reg_code(confirm_id[0], confirm_id[1], json['confirm_code'])
		
		return check_result

	###########################################################
	## Не для API методов, а для получения данных о юзерах
	###########################################################
	async def get_user_info(self, data):
		result = {}
		# парсинг принятого json
		json = self.For_Methods.parseJson(data)
		if(json["response"]=="error"): # если неудачно
			return json
		
		json = json["data"]
		if('data' in json):
			if('token' in json['data']):
				result = await self.DB_Users.check_token(json['data']['token'])
				if(result['response']=="ok"):
					return result
				else:
					result["response"] = "error"
					result['error_code'] = 37
					result['error_msg'] = "Ошибка! Код 37"
					return result
			else:
				result["response"] = "error"
				result['error_code'] = 31
				result['error_msg'] = "Ошибка! Код 31"
				return result
		else:
			result["response"] = "error"
			result['error_code'] = 31
			result['error_msg'] = "Ошибка! Код 31"
			return result