import asyncio
import aiomysql
import json
from __class_for_all_methods import For_Methods


class DB_Stat:
    def __init__(self):
        self.db_host = "localhost"
        self.db_name = "horizons_stat"
        self.db_user = "horizons_stat"
        self.db_pass = "Stat1234"
        self.db_port = 3306
        self.For_Methods = For_Methods()

    async def get_glavn_graph(self):
        db = await self.For_Methods.db_connect(self.db_name, self.db_user, self.db_pass, self.db_host, self.db_port)

        result = {}

        if (db != False):
            try:
                #col = '2024-05-18'
                sql = "SELECT DATE_FORMAT(time_, '%H:%i') AS minute, SUM(capacity) AS total_capacity FROM statistic WHERE date_ = '2024-05-18' AND time_ BETWEEN SUBTIME(CURTIME(), '01:00:00') AND CURTIME() GROUP BY minute ORDER BY minute;"
                cur = await db['connect'].cursor(aiomysql.DictCursor)
                #data = (col,)
                await cur.execute(sql)
                r = await cur.fetchall()
                await cur.close()
                return r
            except:
                return False

    async def all_phiders(self):
        db = await self.For_Methods.db_connect(self.db_name, self.db_user, self.db_pass, self.db_host, self.db_port)

        result = {}

        if (db != False):
            try:
                #col = '2024-05-18'
                sql = "SELECT * FROM `phider`"
                cur = await db['connect'].cursor(aiomysql.DictCursor)
                #data = (col,)
                await cur.execute(sql)
                r = await cur.fetchall()
                await cur.close()
                return r
            except:
                return False

    async def phider_info(self, phider_id):
        db = await self.For_Methods.db_connect(self.db_name, self.db_user, self.db_pass, self.db_host, self.db_port)

        result = {}

        if (db != False):
            try:
                #col = '2024-05-18'
                sql = "SELECT DATE_FORMAT(time_, '%H:%i') AS minute, SUM(capacity) AS total_capacity FROM statistic WHERE id_phider="+str(phider_id)+" AND date_ = '2024-05-18' AND time_ BETWEEN SUBTIME(CURTIME(), '01:00:00') AND CURTIME() GROUP BY minute ORDER BY minute;"
                #print(sql)
                cur = await db['connect'].cursor(aiomysql.DictCursor)
                #data = (phider_id,)
                await cur.execute(sql)
                r = await cur.fetchall()
                await cur.close()
                return r
            except:
                return False

    async def kvt_day(self):
        db = await self.For_Methods.db_connect(self.db_name, self.db_user, self.db_pass, self.db_host, self.db_port)

        result = {}

        if (db != False):
            try:
                #col = '2024-05-18'
                sql = "SELECT SUM(capacity/60) AS total_capacity FROM statistic WHERE CONCAT(date_, ' ', time_) >= '2024-05-18 00:03:00' - INTERVAL 1 DAY;"
                cur = await db['connect'].cursor(aiomysql.DictCursor)
                #data = (col,)
                await cur.execute(sql)
                r = await cur.fetchall()
                await cur.close()
                return r
            except:
                return False

    async def data_old_day(self):
        db = await self.For_Methods.db_connect(self.db_name, self.db_user, self.db_pass, self.db_host, self.db_port)

        result = {}

        if (db != False):
            try:
                #col = '2024-05-18'
                sql = "SELECT SUM(capacity) AS total_capacity FROM statistic WHERE date_ = '2024-05-18' AND time_ BETWEEN SUBTIME(CURTIME(), '24:00:00') AND CURTIME();"
                cur = await db['connect'].cursor(aiomysql.DictCursor)
                #data = (col,)
                await cur.execute(sql)
                r = await cur.fetchall()
                await cur.close()
                return r
            except:
                return False


    async def krit_sobyt(self):
        db = await self.For_Methods.db_connect(self.db_name, self.db_user, self.db_pass, self.db_host, self.db_port)

        result = {}

        if (db != False):
            try:
                #col = '2024-05-18'
                sql = "SELECT factory.short_name, workshop_phider.id_workshop,status.id_phider, status.time_begin, status.time_end, status.notification FROM status JOIN workshop_phider ON status.id_phider = workshop_phider.id_phider JOIN factory ON workshop_phider.id_factory = factory.id_factory WHERE status.notification = \"1\" AND status.date_status = \"2024-05-17\" LIMIT 10;"
                cur = await db['connect'].cursor(aiomysql.DictCursor)
                #data = (col,)
                await cur.execute(sql)
                r = await cur.fetchall()
                await cur.close()
                return r
            except:
                return False

    async def prostoy_predpr(self):
        db = await self.For_Methods.db_connect(self.db_name, self.db_user, self.db_pass, self.db_host, self.db_port)

        result = {}

        if (db != False):
            try:
                #col = '2024-05-18'
                sql = "SELECT SUM(TIMESTAMPDIFF(SECOND, CONCAT(s.date_status, ' ', s.time_begin), CONCAT(s.date_status, ' ', s.time_end))) / 3600 AS total_simple_status_time_hours FROM status AS s JOIN phider AS p ON s.id_phider = p.id_phider JOIN workshop_phider AS wp ON p.id_phider = wp.id_phider JOIN factory AS f ON wp.id_factory = f.id_factory WHERE s.type_status = 'Простой' AND f.id_factory = 1;"
                cur = await db['connect'].cursor(aiomysql.DictCursor)
                #data = (col,)
                await cur.execute(sql)
                r = await cur.fetchall()
                await cur.close()
                return r
            except:
                return False


    async def prostoy_phider(self, phider_id):
        db = await self.For_Methods.db_connect(self.db_name, self.db_user, self.db_pass, self.db_host, self.db_port)

        result = {}

        if (db != False):
            try:
                #col = '2024-05-18'
                sql = "SELECT SUM(TIMESTAMPDIFF(MINUTE, status.time_begin, status.time_end)) AS sum FROM status WHERE status.type_status IN ('Простой') AND status.time_end >= \"2024-05-18 00:03:00\" - INTERVAL 24 HOUR AND status.id_phider = \""+phider_id+"\";"
                cur = await db['connect'].cursor(aiomysql.DictCursor)
                #data = (col,)
                await cur.execute(sql)
                r = await cur.fetchall()
                await cur.close()
                return r
            except:
                return False



    async def raboty_phider(self, phider_id):
        db = await self.For_Methods.db_connect(self.db_name, self.db_user, self.db_pass, self.db_host, self.db_port)

        result = {}

        if (db != False):
            try:
                # col = '2024-05-18'
                sql = "SELECT SUM(TIMESTAMPDIFF(MINUTE, status.time_begin, status.time_end)) AS \"sum\" FROM status WHERE status.type_status IN ('Критический', ' ') AND status.time_end >= \"2024-05-18 00:03:00\" - INTERVAL 24 HOUR AND status.id_phider = \""+phider_id+"\";"
                cur = await db['connect'].cursor(aiomysql.DictCursor)
                # data = (col,)
                await cur.execute(sql)
                r = await cur.fetchall()
                await cur.close()
                return r
            except:
                return False

    async def col_kryt_phider(self, phider_id):
        db = await self.For_Methods.db_connect(self.db_name, self.db_user, self.db_pass, self.db_host, self.db_port)

        result = {}

        if (db != False):
            try:
                # col = '2024-05-18'
                sql = "SELECT COUNT(*) AS \"sum\" FROM status WHERE status.type_status = 'Критический' AND status.id_phider = "+phider_id+" AND status.time_end >= \"2024-05-18 00:03:00\" - INTERVAL 24 HOUR;"
                cur = await db['connect'].cursor(aiomysql.DictCursor)
                # data = (col,)
                await cur.execute(sql)
                r = await cur.fetchall()
                await cur.close()
                return r
            except:
                return False



    

    # функция для создания записи в reg_queue (подтверждение регистрации)
    """async def add_reg_queue(self, firstname, lastname, birthday, sex, email, password, pass_salt, code):
        db = await self.For_Methods.db_connect(self.db_name, self.db_user, self.db_pass, self.db_host, self.db_port)

        result = {}

        if (db != False):
            # проверяем отсутствие пользователя с таким email в users
            query = "SELECT COUNT(*) FROM users WHERE email=%s LIMIT 1"
            data = (email,)
            res = await self.For_Methods.db_select_one(loop=db['loop'], sql=query, data=data, connect=db['connect'])
            count = res['COUNT(*)']

            if (count != 0):  # если нашли пользователя с такой почтой
                result = self.For_Methods.genetate_error_code(8, "Аккаунт с таким E-mail уже зарегистрирован")
                await self.For_Methods.db_disconnect(db['connect'])
                return result
            else:  # если не нашли
                # проверяем наличие в очереди на регистрацию юзера с этой же почтой
                query = "SELECT COUNT(*) FROM reg_queue WHERE email=%s LIMIT 1"
                data = (email,)
                res = await self.For_Methods.db_select_one(loop=db['loop'], sql=query, data=data, connect=db['connect'])
                count = res['COUNT(*)']

                if (count != 0):  # если находим, то удаляем, если удаление прошло неудачно - возвращаем ошибку
                    query = "DELETE FROM reg_queue WHERE email=%s"
                    data = (email,)
                    res = await self.For_Methods.db_delete(loop=db['loop'], sql=query, data=data, connect=db['connect'])
                    if (res == False):
                        result = self.For_Methods.genetate_error_code(9)
                        await self.For_Methods.db_disconnect(db['connect'])
                        return result

                # вставляем в очередь на регистрацию этого юзера
                query = "INSERT INTO reg_queue(firstname, lastname, birthday, sex, email, password, pass_salt, code, attempts, create_time) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"
                data = (firstname, lastname, birthday, sex, email, password, pass_salt, code, '0',
                        self.For_Methods.current_unixtime())
                res = await self.For_Methods.db_insert(loop=db['loop'], sql=query, data=data, connect=db['connect'])

                if (res != False):  # если добавлен в очередь удачно
                    await self.For_Methods.db_disconnect(db['connect'])
                    result["response"] = "ok"
                    return_info = {}
                    return_info['type'] = "confirm_register"
                    return_info['confirm_id'] = str(res) + " " + email
                    result['data'] = json.dumps(return_info)
                    await self.For_Methods.db_disconnect(db['connect'])
                    return result
                else:  # если добавлен в очередь НЕудачно
                    result = self.For_Methods.genetate_error_code(10)
                    await self.For_Methods.db_disconnect(db['connect'])
                    return result
        else:  # если неудачное подключение к БД
            result = self.For_Methods.genetate_error_code(11)
            await self.For_Methods.db_disconnect(db['connect'])
            return result

    # функция для проверки кода и добавления юзера в БД
    async def check_reg_code(self, confirm_id, email, confirm_code):
        db = await self.For_Methods.db_connect(self.db_name, self.db_user, self.db_pass, self.db_host, self.db_port)

        result = {}

        if (db != False):
            # ищем нужный id и email для подтверждения
            query = "SELECT * FROM reg_queue WHERE id=%s AND email=%s LIMIT 1"
            data = (confirm_id, email)
            user_info = await self.For_Methods.db_select_one(loop=db['loop'], sql=query, data=data,
                                                             connect=db['connect'])
            if (user_info == None or user_info == False):  # если не нашли
                result = self.For_Methods.genetate_error_code(16,
                                                              "Невозможно завершить регистрацию. Попробуйте зарегистрироваться повторно")
                await self.For_Methods.db_disconnect(db['connect'])
                return result
            else:  # если нашли
                if (str(user_info['code']) != str(confirm_code)):  # сраниваем код, если разные
                    if (int(user_info[
                                'attempts']) >= 2):  # если попыток было более 3х (отсчет с нуля), то удаляем запись в очереди регистрации
                        query = "DELETE FROM reg_queue WHERE id=%s"
                        data = (confirm_id,)
                        res = await self.For_Methods.db_delete(loop=db['loop'], sql=query, data=data,
                                                               connect=db['connect'])
                        if (res == False):  # если удалить не получилось
                            result = self.For_Methods.genetate_error_code(18)
                            await self.For_Methods.db_disconnect(db['connect'])
                            return result
                        else:  # если удалить запись в очереди регистрации получилось
                            result = self.For_Methods.genetate_error_code(19,
                                                                          "Неправильный код, невозможно завершить регистрацию. Попробуйте зарегистрироваться повторно")
                    else:  # если попыток было менее 3х
                        result = self.For_Methods.genetate_error_code(17,
                                                                      "Неправильный код, попробуйте ввести повторно")
                        # добавляем +1 к attemts (попытки)
                        query = "UPDATE reg_queue SET attempts = %s WHERE id=%s"
                        data = (str(int(user_info['attempts']) + 1), confirm_id)
                        res = await self.For_Methods.db_update(loop=db['loop'], sql=query, data=data,
                                                               connect=db['connect'])
                else:  # если код правильный
                    # удаляем из очереди регистрации
                    query = "DELETE FROM reg_queue WHERE id=%s"
                    data = (confirm_id,)
                    res = await self.For_Methods.db_delete(loop=db['loop'], sql=query, data=data, connect=db['connect'])
                    if (res == False):  # если удалить не получилось
                        result = self.For_Methods.genetate_error_code(20)
                        await self.For_Methods.db_disconnect(db['connect'])
                        return result
                    # добавляем юзера в БД
                    query = "INSERT INTO users(firstname,lastname,birthday,sex,photo,email,password,pass_salt,tokens,banned,reg_date) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"
                    data = (user_info['firstname'], user_info['lastname'], user_info['birthday'], user_info['sex'], '',
                            user_info['email'], user_info['password'], user_info['pass_salt'], '', '0',
                            self.For_Methods.date_today())
                    res = await self.For_Methods.db_insert(loop=db['loop'], sql=query, data=data, connect=db['connect'])

                    if (res != False):  # если удачно
                        result["response"] = "ok"
                        return_info = {}
                        return_info['token'] = await self.add_token(res)
                        return_info['token'] = str(res) + "_" + return_info['token']['data']
                        result['data'] = json.dumps(return_info)
                    else:  # если неудачно
                        result = self.For_Methods.genetate_error_code(21)
                        await self.For_Methods.db_disconnect(db['connect'])
                        return result

                await self.For_Methods.db_disconnect(db['connect'])
                return result
        else:
            result = self.For_Methods.genetate_error_code(15)
            await self.For_Methods.db_disconnect(db['connect'])
            return result

    async def auth(self, login, password):
        result = {}

        db = await self.For_Methods.db_connect(self.db_name, self.db_user, self.db_pass, self.db_host, self.db_port)

        if (db != False):
            # проверяем отсутствие пользователя с таким email в users
            query = "SELECT * FROM users WHERE email=%s LIMIT 1"
            data = (login,)
            user_info = await self.For_Methods.db_select_one(loop=db['loop'], sql=query, data=data,
                                                             connect=db['connect'])
            if (user_info == None or user_info == False):
                result = self.For_Methods.genetate_error_code(27, "Неверный логин/пароль")
                await self.For_Methods.db_disconnect(db['connect'])
                return result
            else:
                if (user_info['password'] != self.For_Methods.sha256(password + user_info['pass_salt'])):
                    result = self.For_Methods.genetate_error_code(27, "Неверный логин/пароль")
                    await self.For_Methods.db_disconnect(db['connect'])
                    return result
                else:
                    if (user_info['banned'] == 1):
                        result = self.For_Methods.genetate_error_code(28, "Пользователь заблокирован")
                        await self.For_Methods.db_disconnect(db['connect'])
                        return result
                    else:
                        result["response"] = "ok"
                        token = await self.add_token(user_info['id'])
                        if (token["response"] == "error"):
                            result = token  # в token будет содержаться инфа об ошибке а не токен
                        else:
                            return_info = {}
                            return_info['token'] = await self.add_token(user_info['id'])
                            return_info['token'] = str(user_info['id']) + "_" + return_info['token']['data']
                            result['data'] = json.dumps(return_info)
                        await self.For_Methods.db_disconnect(db['connect'])
                        return result

        else:
            result = self.For_Methods.genetate_error_code(26)
            await self.For_Methods.db_disconnect(db['connect'])
            return result

    # функция для добавления токена (после удачной авторизации)
    async def add_token(self, user_id):
        result = {}
        db = await self.For_Methods.db_connect(self.db_name, self.db_user, self.db_pass, self.db_host, self.db_port)

        if (db != False):
            # получаем текущие токены (в json)
            query = "SELECT pass_salt, tokens FROM users WHERE id=%s LIMIT 1"
            data = (user_id,)
            user_info = await self.For_Methods.db_select_one(loop=db['loop'], sql=query, data=data,
                                                             connect=db['connect'])
            if (user_info == None or user_info == False):  # если нет результата или ошибка выполнения запроса
                result = self.For_Methods.genetate_error_code(29)
                await self.For_Methods.db_disconnect(db['connect'])
                return result
            else:  # если результат есть (данные должны быть в json, может быть пустым)
                token_result = {}
                add_token = self.For_Methods.generate_token()  # генерируем токен
                crypted_token = self.For_Methods.sha256(
                    add_token + user_info["pass_salt"])  # шифруем токен, в чистом виде отдаем юзеру
                token_json = self.For_Methods.add_token_to_json(user_info["tokens"],
                                                                crypted_token)  # а шифрованный вносим в json и далее в БД

                query = "UPDATE users SET tokens = %s WHERE id=%s"
                data = (token_json, user_id)
                res = await self.For_Methods.db_update(loop=db['loop'], sql=query, data=data, connect=db['connect'])

                if (res == False):
                    result = self.For_Methods.genetate_error_code(30)
                    await self.For_Methods.db_disconnect(db['connect'])
                    return result
                else:
                    result["response"] = "ok"  # если все ок, возвращаем это и в result["data"] сам токен (не json)
                    result["data"] = add_token
                    await self.For_Methods.db_disconnect(db['connect'])
                    return result
        else:
            result = self.For_Methods.genetate_error_code(22)
            await self.For_Methods.db_disconnect(db['connect'])
            return result

    # функция для проверки токена
    async def check_token(self, token):
        result = {}
        try:
            token = token.split("_", 1)
            if (token[0].isdigit() == True and self.For_Methods.isHashSHA256Valid(token[1])):

                db = await self.For_Methods.db_connect(self.db_name, self.db_user, self.db_pass, self.db_host,
                                                       self.db_port)

                if (db != False):
                    # получаем текущие токены (в json)
                    query = "SELECT * FROM users WHERE id=%s LIMIT 1"
                    data = (token[0],)
                    user_info = await self.For_Methods.db_select_one(loop=db['loop'], sql=query, data=data,
                                                                     connect=db['connect'])
                    if (user_info == None or user_info == False):  # если нет результата или ошибка выполнения запроса
                        result = self.For_Methods.genetate_error_code(34)
                        await self.For_Methods.db_disconnect(db['connect'])
                        return result
                    else:
                        crypted_token = self.For_Methods.sha256(token[1] + user_info["pass_salt"])
                        if (self.For_Methods.check_token_on_json(user_info["tokens"], crypted_token)):
                            result["response"] = "ok"
                            result["data"] = user_info
                            await self.For_Methods.db_disconnect(db['connect'])
                            return result
                        else:
                            result = self.For_Methods.genetate_error_code(35)
                            await self.For_Methods.db_disconnect(db['connect'])
                            return result
                else:
                    result = self.For_Methods.genetate_error_code(33)
                    return result
            else:
                result = self.For_Methods.genetate_error_code(32)
                return result
        except:
            result = self.For_Methods.genetate_error_code(36)
            return result"""