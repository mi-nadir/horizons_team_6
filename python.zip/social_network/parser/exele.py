import asyncio
import aiomysql
import pandas as pd
from datetime import datetime, timedelta

async def fetch_data_from_db():
    pool = await aiomysql.create_pool(
        host='127.0.0.1',
        port=3306,
        user='horizons_stat',
        password='Stat1234',
        db='horizons_stat',
        autocommit=True
    )

    async with pool.acquire() as connection:
        async with connection.cursor() as cursor:
            query = "SELECT date_, time_, capacity, id_phider FROM statistic"
            await cursor.execute(query)
            data = await cursor.fetchall()

    df = pd.DataFrame(data, columns=["Дата", "Время", "Мощность", "Фидер"])
    df.to_excel(f"/python/social_network/parser/Otchet_all.xlsx", index=False)

    pool.close()
    await pool.wait_closed()

async def fetch_data_from_db_month():
    pool = await aiomysql.create_pool(
        host='127.0.0.1',
        port=3306,
        user='horizons_stat',
        password='Stat1234',
        db='horizons_stat',
        autocommit=True
    )

    async with pool.acquire() as connection:
        async with connection.cursor() as cursor:
            month_ago_date = (datetime.now() - timedelta(days=30)).strftime('%Y-%m-%d')
            query = f"""
                SELECT date_, time_, capacity, id_phider
                FROM statistic
                WHERE date_ BETWEEN '{month_ago_date}' AND CURDATE()
            """
            await cursor.execute(query)
            data = await cursor.fetchall()

    df = pd.DataFrame(data, columns=["Дата", "Время", "Мощность", "Фидер"])
    df.to_excel(f"/python/social_network/parser/Otchet.xlsx", index=False)

    pool.close()
    await pool.wait_closed()

# Запуск асинхронных задач
asyncio.run(fetch_data_from_db())
asyncio.run(fetch_data_from_db_month())
