import asyncio
import aiomysql

async def main():
    # Подключение к базе данных
    pool = await aiomysql.create_pool(host='127.0.0.1', port=3306,
                                      user='horizons_stat', password='Stat1234',
                                      db='horizons_stat', loop=loop)

    async with pool.acquire() as connection:
        async with connection.cursor() as cursor:
            # Запрос к базе данных
            query = "SELECT * FROM phider"
            await cursor.execute(query)

            # Получение результатов запроса
            results = await cursor.fetchall()

            # Вывод результатов
            for row in results:
                print(row)

    pool.close()
    await pool.wait_closed()

# Создание цикла событий и запуск main()
loop = asyncio.get_event_loop()
loop.run_until_complete(main())