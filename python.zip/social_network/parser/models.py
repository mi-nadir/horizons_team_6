from datetime import datetime

file_path = 'data_new.xlsx'

class Statistic:
    _id_counter = 1

    def __init__(self, date_, time_, capacity: float, id_phider: int):
        self.id = Statistic._id_counter
        Statistic._id_counter += 1
        self.date_ = date_
        self.time_ = time_
        self.capacity = capacity
        self.id_phider = id_phider

    def __str__(self):
        return (f"Statistic(id={self.id}, date_={self.date_}, time_={self.time_}, "
                f"capacity={self.capacity}, id_phider={self.id_phider})")


class Status:
    id_status = 1

    def __init__(self, time_begin: datetime.time, time_end: datetime.time, type_status: str, id_phider: int, date_status: datetime.date):
        self.id_status = Status.id_status
        Status.id_status += 1
        self.time_begin = time_begin
        self.time_end = time_end
        self.type_status = type_status
        self.id_phider = id_phider
        self.date_status = date_status

    def __str__(self):
        return (f"Status(id_status={self.id_status}, time_begin={self.time_begin}, time_end={self.time_end}, "
                f"type_status={self.type_status}, id_phider={self.id_phider}, date_status={self.date_status})")


