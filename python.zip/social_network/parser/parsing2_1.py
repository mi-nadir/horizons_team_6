import pandas as pd
import asyncio
import aiomysql
from models import *

df = pd.read_excel(file_path, parse_dates=['Дата'])

statistics = []
for index, row in df.iterrows():
    date_time = row['Дата']
    date_ = date_time.date()
    time_ = date_time.time()
    statistic_instance = Statistic(date_, time_, row['Мощность'], row['Фидер'])
    statistics.append(statistic_instance)

async def main():
    # Подключение к базе данных
    pool = await aiomysql.create_pool(host='127.0.0.1', port=3306,
                                      user='horizons_stat', password='Stat1234',
                                      db='horizons_stat', loop=loop)

    async with pool.acquire() as connection:
        async with connection.cursor() as cursor:
            # Добавление данных в таблицу statistic
            for statistic_instance in statistics:
                # Проверка существования записи
                query_check_statistic = """
                    SELECT * FROM statistic WHERE date_ = %s AND time_ = %s AND capacity = %s AND id_phider = %s
                """
                await cursor.execute(query_check_statistic, 
                                    (statistic_instance.date_, 
                                    statistic_instance.time_, 
                                    statistic_instance.capacity, 
                                    statistic_instance.id_phider))
                result_statistic = await cursor.fetchone()
                
                if result_statistic is None:
                    query_statistic = """
                        INSERT INTO statistic (date_, time_, capacity, id_phider) 
                        VALUES (%s, %s, %s, %s) """
                    await cursor.execute(query_statistic, 
                                        (statistic_instance.date_, 
                                        statistic_instance.time_, 
                                        statistic_instance.capacity, 
                                        statistic_instance.id_phider))
                
                # Проверка и добавление id_phider в таблицу phider, если он не существует
                query_check_phider = "SELECT id_phider FROM phider WHERE id_phider = %s"
                await cursor.execute(query_check_phider, (statistic_instance.id_phider,))
                result_phider = await cursor.fetchone()
                
                if result_phider is None:
                    query_phider = "INSERT INTO phider (id_phider) VALUES (%s)"
                    await cursor.execute(query_phider, (statistic_instance.id_phider,))

        # Сохранение изменений
        await connection.commit()

    # Закрытие пула подключений
    pool.close()
    await pool.wait_closed()

# Создание цикла событий и запуск main()
loop = asyncio.get_event_loop()
loop.run_until_complete(main())
