import telebot
import aiomysql
import asyncio

# Initialize the bot with your token
API_TOKEN = ''
bot = telebot.TeleBot(API_TOKEN)

async def get_critical_status():
    pool = None
    try:
        # Connect to your database
        pool = await aiomysql.create_pool(
            host='127.0.0.1',
            port=3306,
            user='horizons_stat',
            password='Stat1234',
            db='horizons_stat')
        
        async with pool.acquire() as conn:
            async with conn.cursor(aiomysql.DictCursor) as cur:
                # Define the query to fetch critical status rows with information from phiders table
                query = """
                SELECT factory.short_name AS "Наименование предприятия",
                       status.id_phider AS "Номер фидера",
                       status.date_status AS "Дата инцидента",
                       status.time_begin AS "Время инцидента"
                FROM status
                JOIN workshop_phider ON status.id_phider = workshop_phider.id_phider
                JOIN factory ON workshop_phider.id_factory = factory.id_factory
                WHERE status.notification = %s
                ORDER BY status.time_begin;
                """
                await cur.execute(query, ("1",))
                
                # Fetch all rows
                rows = await cur.fetchall()
                return rows
    
    except Exception as e:
        return str(e)
    
    finally:
        if pool:
            pool.close()
            await pool.wait_closed()

@bot.message_handler(commands=['start'])
def start_command(message):
    asyncio.run(handle_critical_status(message))

@bot.message_handler(commands=['critical_status'])
def send_critical_status(message):
    asyncio.run(handle_critical_status(message))

async def handle_critical_status(message):
    rows = await get_critical_status()
    if isinstance(rows, str):  # In case of an error message
        bot.reply_to(message, rows)
    elif not rows:
        bot.reply_to(message, "No critical statuses found.")
    else:
        for row in rows:
            # Format the message using f-strings
            result = (
                f"Наименование предприятия: {row['Наименование предприятия']}\n"
                f"Номер фидера: {row['Номер фидера']}\n"
                f"Дата инцидента: {row['Дата инцидента']}\n"
                f"Время инцидента: {row['Время инцидента']}\n"
            )
            bot.send_message(message.chat.id, result)
            await asyncio.sleep(30)

# Start polling
if __name__ == "__main__":
    bot.polling()

