import asyncio
from generator import get_phiders_limits, generate_and_save_power
# Основная функция для запуска процесса
async def main():
    loop = asyncio.get_event_loop()
    phiders_limits = await get_phiders_limits(loop)
    await generate_and_save_power(phiders_limits, loop)


# Запуск основного цикла событий
if __name__ == "__main__":
    loop = asyncio.get_event_loop()
    loop.run_until_complete(main())
    
    


