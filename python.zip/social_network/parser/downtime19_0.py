import asyncio
import aiomysql
from datetime import datetime, timedelta
from models import *
from collections import deque

async def get_status():
    statistics = []
    status = []
    id_phider = 2               # Сконнектить с сайтом
    target_date = "2024-05-18"  #

    # Подключение к базе данных
    pool = await aiomysql.create_pool(host='127.0.0.1', port=3306,
                                      user='horizons_stat', password='Stat1234',
                                      db='horizons_stat', loop=loop)

    async with pool.acquire() as connection:
        async with connection.cursor() as cursor:
            query = """
                SELECT time_, capacity 
                FROM statistic 
                WHERE id_phider = %s AND date_ = %s
                ORDER BY time_ DESC
            """
            await cursor.execute(query, (id_phider, target_date,))

            # Получение результатов запроса
            results = await cursor.fetchall()

            # Преобразование результатов в экземпляры класса Statistic
            for row in results:
                time_, capacity = row
                statistic_instance = Statistic(target_date, time_, capacity, id_phider)
                statistics.append(statistic_instance)

            await cursor.execute("""
                SELECT no_load_percent, power_raiting 
                FROM phider 
                WHERE id_phider = %s
            """, (id_phider,))
            result = await cursor.fetchone()

            if result is not None:
                no_load_percent, power_raiting = result
            else:
                no_load_percent, power_raiting = 0.2, 1000

            downtime = no_load_percent * power_raiting
            step = timedelta(minutes=1)
            
            downtime_stack = deque()
            critical_stack = deque()
            normal_stack = deque()

            for element in statistics:
                if element.capacity < downtime:
                    downtime_stack.append(element)
                elif element.capacity > power_raiting:
                    critical_stack.append(element)
                elif downtime <= element.capacity <= power_raiting:
                    normal_stack.append(element)

            temp = []
            temp.append(downtime_stack[0])
            for i in range(1, len(downtime_stack)):
                if downtime_stack[i-1].time_ - downtime_stack[i].time_ == step:
                    temp.append(downtime_stack[i])
                elif len(temp)>1:
                    if len(temp) < 10:
                        temp.clear()
                    elif len(temp)>1:
                        status.append(Status(temp[0].time_, temp.pop().time_, "Простой", id_phider, target_date))
                        temp.clear()

            temp.clear()
            temp.append(critical_stack[0])
            for i in range(1, len(critical_stack)):
                if critical_stack[i-1].time_ - critical_stack[i].time_ == step:
                    temp.append(critical_stack[i])
                elif len(temp)>1:
                    status.append(Status(temp[0].time_, temp.pop().time_, "Критический", id_phider, target_date))
                    temp.clear()

            temp.clear()
            temp.append(normal_stack[0])
            for i in range(1,len(normal_stack)):
                if normal_stack[i-1].time_ - normal_stack[i].time_ == step:
                    temp.append(normal_stack[i])
                    
                elif len(temp)>1:
                    status.append(Status(temp[0].time_, temp.pop().time_, " ", id_phider, target_date))
                    temp.clear()

            # Добавление элементов массива status в таблицу status
            insert_query = """
                INSERT INTO status (id_phider, date_status, time_begin, time_end, type_status) 
                VALUES (%s, %s, %s, %s, %s)
            """	
            async with connection.cursor() as insert_cursor:
                for s in status:
                    await insert_cursor.execute(insert_query, (s.id_phider, s.date_status, s.time_end,s.time_begin, s.type_status))
                    
                await connection.commit()

    # Закрытие пула подключений
    pool.close()
    await pool.wait_closed()

    return statistics

# Создание цикла событий и запуск функции get_status()
loop = asyncio.get_event_loop()
statistics = loop.run_until_complete(get_status())
