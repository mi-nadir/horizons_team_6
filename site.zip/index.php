<?php
	include_once("config.php");

	$template = new Template("core/view/");

	if(isset($_COOKIE["token"])) {
		$_POST["data"]["token"] = $_COOKIE["token"];
	}

	switch (ROUTE[0]) {
		case '/':
			include_once("core/controller/stat_controller.php");			
			break;
		case 'im':
			include_once("core/controller/im_controller.php");
			break;
		case 'stat':
			include_once("core/controller/stat_controller.php");
			break;
		case 'profile':
			include_once("core/controller/profile_controller.php");
			break;
	}