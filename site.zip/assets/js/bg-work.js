function menuClick(selected_itm) {
	let menu_item = document.querySelectorAll('.menu-item');
	menu_item.forEach(function(elem){
		elem.removeAttribute('id');
	});
	document.getElementsByClassName(selected_itm)[0].id = 'menu-active';

	var request_url;
	if(selected_itm=="menu-im") { request_url = '/im' }
	if(selected_itm=="menu-stat") { request_url = '/stat' }
	if(selected_itm=="menu-profile") { request_url = '/profile' }

	var xhr = new XMLHttpRequest();
	xhr.open("POST", request_url, true);
	xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

	xhr.onreadystatechange = function() {//Call a function when the state changes.
		if(xhr.readyState == 4 && xhr.status == 200) {
			///console.log(xhr.responseText);
			var data = JSON.parse(xhr.responseText);

			if(data.html=='no_login') {
				window.location = "/";
			} else {
				document.getElementById('content_info').innerHTML = data.html;
			
				history.pushState(null, null, request_url);

				if(selected_itm=="menu-stat") {
					var scripts = Array.from(document.getElementById('content_info').getElementsByTagName('script'));
				    for (let oldScript of scripts) {
				        var newScript = document.createElement('script');
				        newScript.text = oldScript.text;
				        // Заменяем старый скрипт новым
				        oldScript.parentNode.replaceChild(newScript, oldScript);
				    }
					setTimeout(() => { 
						displNone();
					}, 1000);
				}
			}
		}
	}
	xhr.send('js_request=true');
}

function urlClick(request_url) {
	var xhr = new XMLHttpRequest();
	xhr.open("POST", request_url, true);
	xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

	xhr.onreadystatechange = function() {//Call a function when the state changes.
		if(xhr.readyState == 4 && xhr.status == 200) {
			var data = JSON.parse(xhr.responseText);

			if(data.html=='no_login') {
				window.location = "/";
			} else {
				document.getElementById('content_info').innerHTML = data.html;
			
				history.pushState(null, null, request_url);
			}
		}
	}
	xhr.send('js_request=true');
}