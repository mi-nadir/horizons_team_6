function sendRequest(method, info, callback) {
	var xhr = new XMLHttpRequest();
	xhr.open("POST", "/api/"+method+".php", true);
	xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

	xhr.onreadystatechange = function() {//Call a function when the state changes.
		if(xhr.readyState == 4 && xhr.status == 200) {
			callback(JSON.parse(xhr.responseText));
		}
	}
	var token = getCookie('token');
	if(token != undefined) {
		info.set('token', token);
	}
	var send_info = "data="+JSON.stringify(Object.fromEntries(info));
	send_info += "&js_request=true";
	xhr.send(send_info);
}

// возвращает куки с указанным name,
// или undefined, если ничего не найдено
function getCookie(name) {
	let matches = document.cookie.match(new RegExp(
		"(?:^|; )" + name.replace(/([\.$?*|{}\(\)\[\]\\\/\+^])/g, '\\$1') + "=([^;]*)"
	));
	return matches ? decodeURIComponent(matches[1]) : undefined;
}

function deleteCookie(name) {
	setCookie(name, "", {
		'max-age': -1
	})
}

function setCookie(name, value, options = {}) {
	options = {
		path: '/',
		samesite: 'lax',
		...options
	};

	if (options.expires instanceof Date) {
	options.expires = options.expires.toUTCString();
	}

	let updatedCookie = encodeURIComponent(name) + "=" + encodeURIComponent(value);

	for (let optionKey in options) {
		updatedCookie += "; " + optionKey;
		let optionValue = options[optionKey];
		if (optionValue !== true) {
			updatedCookie += "=" + optionValue;
		}
	}
	document.cookie = updatedCookie;
}