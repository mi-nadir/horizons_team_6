function button_search_friend_click() {
	const input_search_friend = document.getElementById('search_friend');
	var input_value = input_search_friend.value;

	if(input_value=="") {
		console.log('clear');
	} else {
		var info = new Map();
		info.set("search", input_value);
		sendRequest("friends.search", info, result => {
			console.log(result);
		});
	}
}

window.onload = function() {
	im_register_listener();
}

function im_register_listener() {
	const input_search_friend = document.getElementById('search_friend');
	input_search_friend.addEventListener('search', button_search_friend_click);
	input_search_friend.addEventListener('keyup', function () {
		if(input_search_friend.value=="") {
			button_search_friend_click();
		}
	});
}