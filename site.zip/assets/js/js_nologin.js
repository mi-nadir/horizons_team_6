let deferredPrompt;

window.addEventListener('beforeinstallprompt', (e) => {
	e.preventDefault();
	deferredPrompt = e;
});

window.addEventListener('appinstalled', () => {
	document.getElementById("install-block").style.display = "none";
	deferredPrompt = null;
});


const EMAIL_REGEXP = /^(([^<>()[\].,;:\s@"]+(\.[^<>()[\].,;:\s@"]+)*)|(".+"))@(([^<>()[\].,;:\s@"]+\.)+[^<>()[\].,;:\s@"]{2,})$/iu;
function isEmailValid(value) {
	return EMAIL_REGEXP.test(value);
}

function isPasswordValid(password) {
	var upperCaseLetters = /[A-ZА-Я]/g;
	var numbers = /[0-9]/g;
	var lowerCaseLetters = /[a-z]/g;
	if((password.match(upperCaseLetters) && password.match(numbers) && password.match(lowerCaseLetters) && password.length >= 8) || password=='') {
		return true;
	} else {
		return false;
	}
}

window.onload = function() {
	document.getElementById('install').addEventListener('click', async () => {
		deferredPrompt.prompt();
		const { outcome } = await deferredPrompt.userChoice;
		deferredPrompt = null;
	});

	var elements = ["sign-up-firstname", "sign-up-lastname"];
	elements.forEach((elem) => {
		document.querySelector('input[name='+elem+']').addEventListener('input', async () => {
			elem_name = document.querySelector('input[name='+elem+']').value
			if(elem_name.length >= 3 || elem_name=='') {
				document.querySelector('input[name='+elem+']').style.borderColor = '';
			} else {
				document.querySelector('input[name='+elem+']').style.borderColor = 'red';
			}
		});
	});

	var elements = ["sign-in-login", "sign-up-login", "restore-login"];
	elements.forEach((elem) => {
		document.querySelector('input[name='+elem+']').addEventListener('input', async () => {
			login = document.querySelector('input[name='+elem+']').value
			if(isEmailValid(login) || login=='') {
				document.querySelector('input[name='+elem+']').style.borderColor = '';
			} else {
				document.querySelector('input[name='+elem+']').style.borderColor = 'red';
			}
		});
	});

	var elements = ["sign-in-password", "sign-up-password", "sign-up-ok-password", "new_password", "new_ok_password"];
	elements.forEach((elem) => {
		document.querySelector('input[name='+elem+']').addEventListener('input', async () => {
			var password = document.querySelector('input[name='+elem+']').value
			if(isPasswordValid(password)) {
				document.querySelector('input[name='+elem+']').style.borderColor = '';
			} else {
				document.querySelector('input[name='+elem+']').style.borderColor = 'red';
			}
		});
	});

	document.querySelector('input[name=confirm_code]').addEventListener('keyup', function () {
		if(document.querySelector('input[name=confirm_code]').value.length >= 8) {
			document.querySelector('input[name=confirm_code]').value = document.querySelector('input[name=confirm_code]').value.slice(0,8)
		}
		document.querySelector('input[name=confirm_code]').value = document.querySelector('input[name=confirm_code]').value.match(/\d+/)
	});
}

function show_form(name) {
	elements = ["sign-in","sign-up","confirm","restore","new_password"]
	if(elements.includes(name)) {
		document.getElementById('auth_error_msg').innerHTML = ""
		document.getElementById('reg_error_msg').innerHTML = ""
		document.getElementById('confirm_error_msg').innerHTML = ""
		document.getElementById('restore_error_msg').innerHTML = ""
		document.getElementById('new_password_error_msg').innerHTML = ""

		elements.forEach((elem) => {
			if(elem==name) {
				document.getElementById(elem).style.display = "block";
			} else {
				document.getElementById(elem).style.display = "none";
			}
		});
	}
}

async function click_sign_btn(name) {
	if(name=='sign-in') {
		document.getElementById('auth_error_msg').innerHTML = ""

		var info = new Map();
		info.set('sign-in-login', document.querySelector('input[name=sign-in-login]').value.toLowerCase());
		info.set('sign-in-password', await sha256(info.get('sign-in-login')+document.querySelector('input[name=sign-in-password]').value));

		sendRequest("account.auth", info, result => {
			if(result['response']=='ok') {
				data = JSON.parse(result['data']);
				setCookie('token', data['token'], {secure: true, 'max-age': 2592000});
				window.location = "/";
			}
			if(result['response']=='error') {
				document.getElementById('auth_error_msg').innerHTML = result['error_msg'];
			}
		});
	}
	if(name=='sign-up') {
		document.getElementById('reg_error_msg').innerHTML = "";

		var info = new Map();
		info.set('sign-up-firstname', document.querySelector('input[name=sign-up-firstname]').value);
		info.set('sign-up-lastname', document.querySelector('input[name=sign-up-lastname]').value);
		info.set('sign-up-login', document.querySelector('input[name=sign-up-login]').value.toLowerCase());
		info.set('sign-up-password', await sha256(info.get('sign-up-login')+document.querySelector('input[name=sign-up-password]').value));
		if(document.querySelector('input[name=sign-up-password]').value == document.querySelector('input[name=sign-up-ok-password]').value) {
			info.set('sign-up-ok-password', info.get('sign-up-password'));
		} else {
			info.set('sign-up-ok-password', await sha256(info.get('sign-up-login')+document.querySelector('input[name=sign-up-ok-password]').value));
		}
		info.set('sign-up-birthday', document.querySelector('input[name=sign-up-birthday]').value);
		info.set('sign-up-sex', document.querySelector('select[name=sign-up-sex]').value);
		sendRequest("account.register", info, result => {
			if(result['response']=='ok') {
				data = JSON.parse(result['data']);
				if(data['type']=="confirm_register") {
					document.querySelector('input[name=confirm_id]').value = data['confirm_id']
					document.querySelector('input[name=confirm_type]').value = "sign-up"
					show_form('confirm');
				}
			}
			if(result['response']=='error') {
				document.getElementById('reg_error_msg').innerHTML = result['error_msg'];
			}
		});
	}
	if(name=='confirm') {
		document.getElementById('confirm_error_msg').innerHTML = "";
		var info = new Map();
		info.set('confirm_code', document.querySelector('input[name=confirm_code]').value);
		info.set('confirm_id', document.querySelector('input[name=confirm_id]').value);

		var type = document.querySelector('input[name=confirm_type]').value;
		if(type=='sign-up') { url = "account.confirm" }
		if(type=='restore') { url = "account.restore" }
		sendRequest(url, info, result => {
			if(result['response']=='ok') {
				data = JSON.parse(result['data']);
				setCookie('token', data['token'], {secure: true, 'max-age': 2592000});
				window.location = "/";
			}
			if(result['response']=='error') {
				document.getElementById('confirm_error_msg').innerHTML = result['error_msg'];
			}
		});
	}
}