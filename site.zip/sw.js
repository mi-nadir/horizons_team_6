'use strict';

function hndlEventFetch(evt) {}

self.addEventListener('fetch', hndlEventFetch);