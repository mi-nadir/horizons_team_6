<?php
	//*********************************************
	// ПЕРЕНАПРАВЛЕНИЯ
	//*********************************************
	/*
	//если пользователь запрашивает сайт с www в начале, то удаляем www
	if (preg_match("/^www\./i", $_SERVER['HTTP_HOST'])) {
		$location = preg_replace('/^www\./i', '', $_SERVER['HTTP_HOST']); // удаляем www
		header('HTTP/1.1 301 Moved Permanently'); // указываем что эта страница перенесена навсегда
		header('Location: https://'.$location); // делаем редирект на главную
		exit; //обязательно завершаем скрипт после редиректа
	}
	//если переходят на страницу без https (защищенный протокол)
	if (empty($_SERVER['HTTPS']) || $_SERVER['HTTPS'] === "off") {
		$location = 'https://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']; //строим url именно с https
		header('HTTP/1.1 301 Moved Permanently'); // указываем что эта страница перенесена навсегда
		header('Location: '.$location); // делаем редирект на главную
		exit; //обязательно завершаем скрипт после редиректа
	}*/

	//удаление index.php из url
	if (preg_match("/^\/index.php/i", $_SERVER['REQUEST_URI'])) { //если в начале url есть "/index.php"
		header("HTTP/1.1 301 Moved Permanently"); // указываем что эта страница перенесена навсегда
		header("Location: /"); // делаем редирект на главную
		exit(); //обязательно завершаем скрипт после редиректа
	}
	//если вызывают config.php
	if (preg_match("/^\/config.php/i", $_SERVER['REQUEST_URI'])) { //если в начале url есть "/config.php"
		header("HTTP/1.1 301 Moved Permanently"); // указываем что эта страница перенесена навсегда
		header("Location: /"); // делаем редирект на главную
		exit(); //обязательно завершаем скрипт после редиректа
	}
	//удаление 2х и более слешей в URL
	if (preg_match("/\/\//", $_SERVER['REQUEST_URI'])) { //если есть 2 слеша подряд
		$route_location = $_SERVER['REQUEST_URI'];
		$route_location = preg_replace('/\/+/', '/', $route_location); // удаляем 2 и более слеша
		$route_location = preg_replace('/\/$/', '', $route_location); //если есть слеш в конце url, то тоже удаляем
		if(strlen($route_location)==0) { // если после замен строка пустая - делаем ее не пустой
			$route_location = '/';
		}
		header("HTTP/1.1 301 Moved Permanently"); // указываем что эта страница перенесена навсегда
		header("Location: ".$route_location);  // делаем редирект
		exit(); //обязательно завершаем скрипт после редиректа
	}
	// удаление слеша в конце url, если есть
	if (preg_match("/^\/(.*?)\/$/", $_SERVER['REQUEST_URI'])) { //если есть слеш в конце
		$route_location = $_SERVER['REQUEST_URI'];
		$route_location = preg_replace('/\/$/', '', $route_location); //если есть слеш в конце url, то удаляем
		if(strlen($route_location)==0) { // если после замен строка пустая - делаем ее не пустой
			$route_location = '/';
		}
		header("HTTP/1.1 301 Moved Permanently"); // указываем что эта страница перенесена навсегда
		header("Location: ".$route_location);  // делаем редирект
		exit(); //обязательно завершаем скрипт после редиректа
	}

	//*********************************************
	// ПОМЕЩАЕМ В КОНСТАНТУ "ROUTE" ТО, ЧТО ВЫЗЫВАЕТ ПОЛЬЗОВАТЕЛЬ
	//*********************************************

	if(isset($_GET['route'])) { //если GET параметр route существует (создается благодаря .htaccess)
		define("ROUTE", explode('/', $_GET['route'])); // пилим ссылку на части и помещаем в константу
	} else { //если GET параметр не существует (пользователь на главной)
		define("ROUTE", array('/')); //помещаем в константу в первом элементе массива "дробь", чтобы было понятно что вызывается главная
	}
	

	//*********************************************
	// КЛАСС ПРОСТОГО ШАБЛОНИЗАТОРА
	//*********************************************

	class Template {
		private $dir_tmpl; // Директория с tpl-файлами
		private $data = array(); // Данные для вывода

		public function __construct($dir_tmpl) {
			$this->dir_tmpl = $dir_tmpl;
		}

		/* Метод для добавления новых значений в данные для вывода */
		public function set($name, $value) {
			$this->data[$name] = $value;
		}

		/* Метод для удаления значений из данных для вывода */
		public function delete($name) {
			unset($this->data[$name]);
		}

		/* При обращении, например, к $this->title будет выводиться $this->data["title"] */
		public function __get($name) {
			if (isset($this->data[$name])) return $this->data[$name];
			return "";
		}

		/* Вывод tpl-файла, в который подставляются все данные для вывода */
		public function display($template) {
			$template = $this->dir_tmpl.$template.".tpl";
			ob_start();
			include ($template);
			echo ob_get_clean();
		}

		// не выводит, а возвращает сгенерированную страницу
		public function return_display($template) {
			$template = $this->dir_tmpl.$template.".tpl";
			ob_start();
			include ($template);
			return ob_get_clean();
		}
	}