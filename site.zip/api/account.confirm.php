<?php
	include_once("_curl_send.php");

	api_method("account.confirm", $_POST);