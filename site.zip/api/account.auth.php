<?php
	include_once("_curl_send.php");

	api_method("account.auth", $_POST);