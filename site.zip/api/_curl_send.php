<?php
	function curl_send($url, $data) {
		$ch = curl_init("http://127.0.0.1:8000".$url);
		curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
		curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
		curl_setopt($ch, CURLOPT_HEADER, false);
		curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
		$result['result'] = curl_exec($ch);
		$result['http_code'] = curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
		curl_close($ch);
		return $result;
	}

	function api_method($method, $post, $return_or_echo = 'echo') {
		if(isset($post['data'])) {
			$data = curl_send('/api/'.$method, $post['data']);
			if($data==false) {
				$return['response'] = "error";
				$return['error_code'] = 2;
				$return['error_msg'] = "Ошибка! Код 2";
			} else {
				if($data['http_code']==200) {
					$return = $data['result'];
				} else {
					$return['response'] = "error";
					$return['error_code'] = 3;
					$return['error_msg'] = "Ошибка! Код 3";
				}
			}
		} else {
			$return['response'] = "error";
			$return['error_code'] = 1;
			$return['error_msg'] = "Ошибка! Код 1";
		}
		if(isset($data['http_code'])) {
			if($data['http_code']==200) {
				if($return_or_echo ==  'echo') { echo $return; }
				if($return_or_echo ==  'return') { return $return; }
			} else {
				if($return_or_echo ==  'echo') { echo json_encode($return); }
				if($return_or_echo ==  'return') { return $return; }
			}
		} else {
			if($return_or_echo ==  'echo') { echo json_encode($return); }
			if($return_or_echo ==  'return') { return $return; }
		}
	}