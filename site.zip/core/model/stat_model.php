<?php
	$menu = array();
	$menu["http://site.ru"] = "Главная";
	$menu["http://site.ru/page-1.html"] = "Страница 1";
	$menu["http://site.ru/page-2.html"] = "Страница 2";
	$menu["http://site.ru/page-3.html"] = time();

	$data['data'] = json_encode($_POST);

	$stat_get = api_method("stat.get", $data, 'return');
	$stat_get = substr($stat_get,0,-1);
	$stat_get = substr( $stat_get, 1);
	$stat_get = str_replace("\\n", "\n", $stat_get);
	$stat_get = str_replace("\\t", "\t", $stat_get);
	$stat_get = str_replace("\\\"", "\"", $stat_get);

	//$stat_get = substr($stat_get,0,1);

	//if(!is_array($friends)) { $friends = json_decode($friends, true); }
	//echo $friends;