<?php
	$menu = array();
	$menu["http://site.ru"] = "Главная";
	$menu["http://site.ru/page-1.html"] = "Страница 1";
	$menu["http://site.ru/page-2.html"] = "Страница 2";
	$menu["http://site.ru/page-3.html"] = time();

	$data['data'] = json_encode($_POST);

	$messages = api_method("messages.getdialogs", $data, 'return');
	if(!is_array($messages)) { $messages = json_decode($messages, true); }
	