<?php
	include_once("api/_curl_send.php");
	include_once("core/model/stat_model.php");
	
	$template->set("menu", $menu);

	//если запрос прилетел от яваскрипта, значит надо возвращать только кусок страницы
	if(isset($_POST['js_request'])) {
		if($friends['response']=='error' or !isset($_COOKIE['token'])) {
			if($friends['error_code']==37 and isset($_COOKIE['token'])) {
				setcookie("token", "", time()-36000000);
			}
			$js_return['html'] = "no_login";
		} else {
			$js_return['title'] = '';
			//$js_return['html'] = $template->return_display("stat_view");
			$js_return['html'] = $stat_get;
		}
		echo json_encode($js_return);
	} else {//если запрос прилетел не от яваскрипта, то надо возвращать все целиком
		if($friends['response']=='error' or !isset($_COOKIE['token'])) {
			if($friends['error_code']==37 and isset($_COOKIE['token'])) {
				setcookie("token", "", time()-36000000);
			}
			$template->display("_nologin_view");
		} else {
			$template->display("_header_view");
			echo $stat_get;
			//$template->display("stat_view");
			$template->display("_footer_view");
		}
	}
?>