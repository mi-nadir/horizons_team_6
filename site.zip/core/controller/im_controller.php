<?php
	include_once("api/_curl_send.php");
	include_once("core/model/im_model.php");
	
	$template->set("menu", $menu);

	// $messages формируется в im_model

	//если запрос прилетел от яваскрипта, значит надо возвращать только кусок страницы
	if(isset($_POST['js_request'])) {
		if($messages['response']=='error') {
			if($messages['error_code']==37 and isset($_COOKIE['token'])) {
				setcookie("token", "", time()-36000000);
			}
			$js_return['html'] = "no_login";
		} else {
			$js_return['title'] = '';
			$js_return['html'] = $template->return_display("im_view");
		}
		echo json_encode($js_return);
	} else {//если запрос прилетел не от яваскрипта, то надо возвращать все целиком
		if($messages['response']=='error') {
			if($messages['error_code']==37 and isset($_COOKIE['token'])) {
				setcookie("token", "", time()-36000000);
			}
			$template->display("_nologin_view");
		} else {
			$template->display("_header_view");
			$template->display("im_view");
			$template->display("_footer_view");
		}
	}
?>